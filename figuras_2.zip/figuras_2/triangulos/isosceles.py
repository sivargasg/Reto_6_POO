from .triangulo import Triangulo
from figuras_2.bases.punto import Punto
from figuras_2.bases.linea import Linea

class Isosceles(Triangulo):
    def __init__(self, base, altura):
        vertices = [Punto(0, 0), Punto(base / 2, altura), Punto(base, 0)]
        bordes = [Linea(vertices[0], vertices[1]),
                  Linea(vertices[1], vertices[2]),
                  Linea(vertices[2], vertices[0])]
        super().__init__(vertices, bordes, es_regular=False)
        self.__base = base
        self.__altura = altura

    def get_base(self):
        return self.__base

    def set_base(self, base):
        self.__base = base

    def get_altura(self):
        return self.__altura

    def set_altura(self, altura):
        self.__altura = altura

    def calcular_area(self):
        return (self.__base * self.__altura) / 2
