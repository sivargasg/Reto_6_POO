import math

from .triangulo import Triangulo
from figuras_2.bases.punto import Punto
from figuras_2.bases.linea import Linea

class TriRectangulo(Triangulo):
    def __init__(self, base, altura):
        self.__base = base
        self.__altura = altura
        vertices = [Punto(0, 0), Punto(base, 0), Punto(0, altura)]
        bordes = [Linea(vertices[0], vertices[1]),
                  Linea(vertices[1], vertices[2]),
                  Linea(vertices[2], vertices[0])]
        super().__init__(vertices, bordes, es_regular=False)
        self.set_angulos_internos(self.calcular_angulos_internos())

    def get_base(self):
        return self.__base

    def set_base(self, base):
        self.__base = base

    def get_altura(self):
        return self.__altura

    def set_altura(self, altura):
        self.__altura = altura

    def calcular_area(self):
        return (self.__base * self.__altura) / 2

    def calcular_angulos_internos(self):
        return [90, math.degrees(math.atan(self.__altura / self.__base)),
                90 - math.degrees(math.atan(self.__altura / self.__base))]