from figuras_2.bases.figura import Figura
from figuras_2.bases.punto import Punto
from figuras_2.bases.linea import Linea

class Rectangulo(Figura):
    def __init__(self, ancho, alto):
        try:
            ancho = float(ancho)
            alto = float(alto)
        except ValueError as error:
            print(f"Error: {error}")
        vertices = [Punto(0, 0), Punto(ancho, 0),
                    Punto(ancho, alto), Punto(0, alto)]
        bordes = [Linea(vertices[0], vertices[1]),
                  Linea(vertices[1], vertices[2]),
                  Linea(vertices[2], vertices[3]),
                  Linea(vertices[3], vertices[0])]
        super().__init__(vertices, bordes, es_regular=True)
        self.__ancho = ancho
        self.__alto = alto

    def get_ancho(self):
       return self.__ancho

    def set_ancho(self, ancho):
        self.__ancho = ancho

    def get_alto(self):
        return self.__alto

    def set_alto(self, alto):
        self.__alto = alto

    def calcular_area(self):
        return self.__ancho * self.__alto

    def calcular_angulos_internos(self):
        return [90, 90, 90, 90]