from .rectangulo import Rectangulo

class Cuadrado(Rectangulo):
    def __init__(self, lado):
        try:
            float(lado)
        except ValueError as error:
            print(f"Error: {error}")
        super().__init__(lado, lado)

    def get_lado(self):
        return self.get_ancho()

    def set_lado(self, lado):
        self.set_ancho(lado)
        self.set_alto(lado)

    def calcular_angulos_internos(self):
        return [90, 90, 90, 90]