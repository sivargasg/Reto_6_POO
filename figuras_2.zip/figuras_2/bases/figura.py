class Figura:
    def __init__(self, vertices, bordes, es_regular):
        self.__vertices = vertices
        self.__bordes = bordes
        self.__es_regular = es_regular
        self.__angulos_internos = []

    def get_vertices(self):
        return self.__vertices

    def set_vertices(self, vertices):
        self.__vertices = vertices

    def get_bordes(self):
        return self.__bordes

    def set_bordes(self, bordes):
        self.__bordes = bordes

    def get_es_regular(self):
        return self.__es_regular

    def set_es_regular(self, es_regular):
        self.__es_regular = es_regular

    def get_angulos_internos(self):
        return self.__angulos_internos

    def set_angulos_internos(self, angulos_internos):
        self.__angulos_internos = angulos_internos

    def calcular_area(self):
        pass

    def calcular_perimetro(self):
        pass

    def calcular_angulos_internos(self):
        try:
            if self.__es_regular and len(self.__vertices) > 2:
                angulo = (len(self.__vertices) - 2) * 180 / len(self.__vertices)
                return [angulo] * len(self.__vertices)
            else:
                return []
        except Exception as e:
            print(f"Error: {e}")